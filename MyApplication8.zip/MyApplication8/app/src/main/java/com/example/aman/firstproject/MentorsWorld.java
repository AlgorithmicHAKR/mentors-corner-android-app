package com.example.aman.firstproject;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MentorsWorld extends AppCompatActivity {

    RecyclerView rv;
    DatabaseReference mref;
    List<com.example.codingcafe.mentorscorner2.BlogDetails> blogList;
    com.example.codingcafe.mentorscorner2.Adapter adapter;
    Button Add_Posts;
    Button doubts;
    @Override
    protected void onStart() {
        super.onStart();
        setContentView(R.layout.activity_mentor_posts);
        rv=findViewById(R.id.mentorpostrv);
        LinearLayoutManager manager=new LinearLayoutManager(this);
        rv.setLayoutManager(manager);
        final  String password=getIntent().getStringExtra("password");
        final String id=getIntent().getStringExtra("mentorid");
        mref= FirebaseDatabase.getInstance().getReference().child("mentors").child(password);
        blogList=new ArrayList<>();
        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                com.example.codingcafe.mentorscorner2.BlogDetails blog=dataSnapshot.getValue(com.example.codingcafe.mentorscorner2.BlogDetails.class);
                blogList.add(blog);
                adapter=new com.example.codingcafe.mentorscorner2.Adapter(MentorsWorld.this,blogList);
                rv.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        doubts=findViewById(R.id.doubts);
        Add_Posts=findViewById(R.id.Add_Posts);
        String admin=getIntent().getStringExtra("admin");
        final String  pno=getIntent().getStringExtra("password");
        if(admin.equals("yes")){
            Add_Posts.setVisibility(View.VISIBLE);

        }else{
            doubts.setVisibility(View.VISIBLE);
        }
        Add_Posts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MentorsWorld.this, com.example.codingcafe.mentorscorner2.addblog.class);
                intent.putExtra("password",pno);
                startActivity(intent);
                finish();
            }
        });


    }
}
