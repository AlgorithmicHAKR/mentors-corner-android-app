package com.example.aman.firstproject;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;

public class MentorAdapter extends RecyclerView.Adapter<MentorAdapter.NayaViewHolder> {
    public static Context context;public String pno;public int val=0;
    public List<MentorDetails> mdlist;public int admin=1;
    public MentorAdapter(Context context, List<MentorDetails> mdlist,int admin,String pno) {
        this.context = context;
        this.admin=admin;
        this.mdlist = mdlist;
    }
    public MentorAdapter(Context context, List<MentorDetails> mdlist,String pno) {
        this.context = context;
        this.mdlist = mdlist;
        this.pno=pno;
    }
    public MentorAdapter(Context context, List<MentorDetails> mdlist,int val ) {
        this.context = context;
        this.mdlist = mdlist;
        this.val=val;
    }

    @NonNull
    @Override
    public MentorAdapter.NayaViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.asinglementor,viewGroup,false);
        return new NayaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MentorAdapter.NayaViewHolder myViewHolder, int i) {
        final MentorDetails mentor=mdlist.get(i);
        myViewHolder.name.setText(mentor.getName());
        myViewHolder.category.setText(mentor.getCategory());
        myViewHolder.rating.setText(mentor.getRating());
        if(val==4) {
            myViewHolder.subscribe.setVisibility(View.VISIBLE);
        }
        myViewHolder.mview.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View v) {
                                                      Intent intent=new Intent(context,MentorsWorld.class);
                                                      //    intent.putExtra("password",pno);
                                                      intent.putExtra("password",pno);
                                                      intent.putExtra("admin","no");
                                                      context.startActivity(intent);
                                                  }
                                              }
        );
        myViewHolder.subscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference db= FirebaseDatabase.getInstance().getReference().child("users").child(pno).child("mentors").child(mentor.getId());
                HashMap<String ,Object> h=new HashMap<>();
                h.put("name",mentor.getName().toString());
                h.put("category",mentor.getCategory().toString());
                h.put("currentlyworkingin",mentor.getCurrentlyworkingin().toString());
                h.put("id",mentor.getId().toString());
                h.put("rating",mentor.getRating().toString());
                h.put("yoe",mentor.getYoe().toString());
                db.updateChildren(h).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(context,"You have Now Subscribed to "+mentor.getName(),Toast.LENGTH_LONG).show();

                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return mdlist.size();
    }
    public static class NayaViewHolder extends RecyclerView.ViewHolder{
        private TextView name,category,rating;
        private Button subscribe;
        public View mview;
        public NayaViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.mdname);
            category=itemView.findViewById(R.id.mdcategory);
            rating=itemView.findViewById(R.id.mdrating);
            subscribe=itemView.findViewById(R.id.subscribe);
            mview=itemView;

        }

    }
}
