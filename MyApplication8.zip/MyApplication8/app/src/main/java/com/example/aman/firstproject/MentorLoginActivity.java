package com.example.aman.firstproject;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MentorLoginActivity extends AppCompatActivity {
    private Button login;
    private EditText email,password;
    private DatabaseReference database;
    private Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mentor_login);
        email=(EditText) findViewById(R.id.mentors_email);
        password=(EditText) findViewById(R.id.mentors_password);
        login=(Button) findViewById(R.id.mentors_login);
        signup=(Button) findViewById(R.id.mentors_signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MentorLoginActivity.this,MentorsSignUp.class);
                startActivity(intent);
                finish();

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database= FirebaseDatabase.getInstance().getReference().child("mentors");

                database.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.hasChild(password.getText().toString())){
                            if( dataSnapshot.child(password.getText().toString()).child("name").getValue().toString().equals(email.getText().toString()))
                            {
                                Intent intent=new Intent(MentorLoginActivity.this,MentorsWorld.class);
                                intent.putExtra("password",password.getText().toString());
                                intent.putExtra("admin","yes");
                                startActivity(intent);
                                finish();
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }
}
