package com.example.aman.firstproject;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
    private Context context;
    public List<BlogDetails> blogList;
    public Adapter(Context context, List<BlogDetails> blogList) {
        this.context = context;
        this.blogList=blogList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.asingleitem,viewGroup,false);
        return new MyViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        BlogDetails blog=blogList.get(i);
        myViewHolder.topic.setText(blog.getTopic());
        myViewHolder.mview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    @Override
    public int getItemCount() {
        return blogList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name,topic,category;public View mview;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.mentorname);
            topic=itemView.findViewById(R.id.mentortopic);
            category=itemView.findViewById(R.id.mentorcategory);
            mview=itemView;
        }
    }


}
