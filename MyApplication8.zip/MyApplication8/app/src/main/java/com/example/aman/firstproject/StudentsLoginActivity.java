package com.example.aman.firstproject;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentsLoginActivity extends AppCompatActivity {
    private Button login;
    private EditText email,password;
    private DatabaseReference database;
    private Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_login);
        email=(EditText) findViewById(R.id.student_email);
        password=(EditText) findViewById(R.id.student_password);
        login=(Button) findViewById(R.id.student_login);
        signup=(Button) findViewById(R.id.student_signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(StudentsLoginActivity.this,StudentsSignUp.class);
                startActivity(intent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database=FirebaseDatabase.getInstance().getReference().child("users");

                database.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if(dataSnapshot.hasChild(password.getText().toString())){
                            if( dataSnapshot.child(password.getText().toString()).child("email").getValue().toString().equals(email.getText().toString()))
                            {
                                Intent intent=new Intent(StudentsLoginActivity.this, com.example.codingcafe.mentorscorner2.StudentsHomeActivity.class);
                                intent.putExtra("password",password.getText().toString());
                                startActivity(intent);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }
}
