package com.example.aman.firstproject;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class Mymentors extends AppCompatActivity {
    private RecyclerView rv;
    private MentorAdapter ma;
    private List<MentorDetails> mentorlist;private Button mentorsadd;
    private DatabaseReference db;
    private String pno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        mentorsadd=findViewById(R.id.mymentorsadd);
        mentorsadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Mymentors.this,allmentors.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        pno=getIntent().getStringExtra("password");
        setContentView(R.layout.activity_mymentors);
        rv=findViewById(R.id.mymentorsrv);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        // ma=new MentorAdapter(this,mentorlist);
        final String phoneno=getIntent().getStringExtra("password");
        db= FirebaseDatabase.getInstance().getReference().child("users").child(phoneno).child("mentors");
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                MentorDetails mentor=(MentorDetails)dataSnapshot.getValue(MentorDetails.class);
                mentorlist.add(mentor);
                ma=new MentorAdapter(Mymentors.this,mentorlist,pno);
                rv.setAdapter(ma);
                ma.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
