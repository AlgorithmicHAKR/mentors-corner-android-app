package com.example.aman.firstproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class allmentors extends AppCompatActivity {
    private RecyclerView rv;private MentorAdapter ma;
    private DatabaseReference db;private List<MentorDetails> allmentorslist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allmentors);
    }

    @Override
    protected void onStart() {
        super.onStart();
        allmentorslist=new ArrayList<>();
        db= FirebaseDatabase.getInstance().getReference().child("mentors");
        rv=findViewById(R.id.allmentorsrv);
        LinearLayoutManager manager=new LinearLayoutManager(this);
        rv.setLayoutManager(manager);
        db.addValueEventListener(new ValueEventListener() {
                                     @Override
                                     public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                         MentorDetails mentor=dataSnapshot.getValue(MentorDetails.class);
                                         allmentorslist.add(mentor);
                                         ma=new MentorAdapter(allmentors.this,allmentorslist,4);
                                         rv.setAdapter(ma);
                                         ma.notifyDataSetChanged();

                                     }
                                     @Override
                                     public void onCancelled(@NonNull DatabaseError databaseError) {

                                     }
                                 }
        );
    }
}
