package com.example.aman.firstproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class addblog extends AppCompatActivity {
    private TextView topic , description;
    private Button post;
    private DatabaseReference db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addblog);
        String pno=getIntent().getStringExtra("password");
        db= FirebaseDatabase.getInstance().getReference().child("mentors").child(pno).child("blogs");
        topic=findViewById(R.id.blog_topic);
        description=findViewById(R.id.blog_description);
        post=findViewById(R.id.blogpost);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String, Object> h=new HashMap<>();
                h.put("topic",topic.getText());
                h.put("description",description.getText());
                db.child(topic.getText().toString()).updateChildren(h);
            }
        });
    }
}
