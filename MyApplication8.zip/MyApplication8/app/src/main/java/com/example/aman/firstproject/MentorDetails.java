package com.example.aman.firstproject;

public class MentorDetails {
    private String name;
    private String category;
    private String yoe;
    private String currentlyworkingin;
    private String rating;
    private String id;
    public MentorDetails(String name, String category, String yoe, String currentlyworkingin,String id) {
        this.name = name;
        this.category = category;
        this.yoe = yoe;this.id=id;
        this.currentlyworkingin = currentlyworkingin;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getYoe() {
        return yoe;
    }

    public void setYoe(String yoe) {
        this.yoe = yoe;
    }

    public String getCurrentlyworkingin() {
        return currentlyworkingin;
    }

    public void setCurrentlyworkingin(String currentlyworkingin) {
        this.currentlyworkingin = currentlyworkingin;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}
