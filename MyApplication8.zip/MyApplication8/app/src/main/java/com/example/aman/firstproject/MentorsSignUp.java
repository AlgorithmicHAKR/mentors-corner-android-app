package com.example.aman.firstproject;

import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class MentorsSignUp extends AppCompatActivity {
    private EditText name ,password, email;
    private Button createacc;
    private DatabaseReference db;
    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_mentors_sign_up);
        db= FirebaseDatabase.getInstance().getReference().child("mentors");
        name=findViewById(R.id.ssignupname);
        email=findViewById(R.id.ssignupemail);
        password=findViewById(R.id.ssignuppassword);
        createacc=findViewById(R.id.ssignupcreate);
        createacc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HashMap<String,Object> h=new HashMap<>();
                h.put("name",name.getText());
                h.put("email",email.getText());
                h.put("password",password.getText());

                db.child(password.getText().toString()).updateChildren(h).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(MentorsSignUp.this,"Account created",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(MentorsSignUp.this, com.example.codingcafe.mentorscorner2.MentorLoginActivity.class));
                        finish();

                    }
                });


            }
        });
    }
}
